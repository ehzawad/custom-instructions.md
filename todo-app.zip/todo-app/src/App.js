import React, { useState, useEffect } from 'react';

const pulseAnimation = `
  @keyframes pulse {
    0% { opacity: 0.6; }
    50% { opacity: 1; }
    100% { opacity: 0.6; }
  }
`;

function TodoApp() {
  const [items, setItems] = useState([]);
  const [input, setInput] = useState('');
  const [editingId, setEditingId] = useState(null);
  const [draggedIndex, setDraggedIndex] = useState(null);
  const [dropIndex, setDropIndex] = useState(null);

  useEffect(() => {
    if (items.length === 0) {
      setEditingId(null);
      setInput('');
    }
  }, [items.length]);

  useEffect(() => {
    if (editingId && !items.find(item => item.id === editingId)) {
      setEditingId(null);
      setInput('');
    }
  }, [items, editingId]);

  const handleSubmit = () => {
    if (input.trim()) {
      if (editingId !== null) {
        setItems(items.map(item =>
          item.id === editingId ? { ...item, text: input } : item
        ));
        setEditingId(null);
      } else {
        setItems([{ id: Date.now(), text: input }, ...items]);
      }
      setInput('');
    }
  };

  const handleEdit = (id, text) => {
    setInput(text);
    setEditingId(id);
  };

  const handleDelete = (id) => {
    setItems(items.filter(item => item.id !== id));
    if (editingId === id) {
      setEditingId(null);
      setInput('');
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  const handleDragStart = (e, index) => {
    setDraggedIndex(index);
    e.currentTarget.style.opacity = '0.4';
    e.currentTarget.style.transform = 'scale(1.02)';
    e.currentTarget.style.boxShadow = '0 8px 16px rgba(0, 0, 0, 0.1)';
  };

  const handleDragEnd = (e) => {
    e.currentTarget.style.opacity = '1';
    e.currentTarget.style.transform = 'none';
    e.currentTarget.style.boxShadow = 'none';
    setDraggedIndex(null);
    setDropIndex(null);
  };

  const handleDragOver = (e, index) => {
    e.preventDefault();
    if (draggedIndex === index) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const midY = rect.top + rect.height / 2;
    const mouseY = e.clientY;
    const isAbove = mouseY < midY;
    
    setDropIndex({
      index: index,
      position: isAbove ? 'top' : 'bottom'
    });
  };

  const handleDrop = (e, index) => {
    e.preventDefault();
    if (draggedIndex === null) return;
    
    const position = dropIndex?.position === 'bottom' ? index + 1 : index;
    const newItems = [...items];
    const [removed] = newItems.splice(draggedIndex, 1);
    newItems.splice(position, 0, removed);
    
    setItems(newItems);
    setDraggedIndex(null);
    setDropIndex(null);
  };

  const getDropLineStyle = (index) => {
    if (!dropIndex) return null;
    if (dropIndex.index !== index) return null;

    return {
      position: 'absolute',
      left: 0,
      right: 0,
      height: '3px',
      backgroundColor: '#3b82f6',
      animation: 'pulse 1.5s infinite',
      [dropIndex.position === 'top' ? 'top' : 'bottom']: 0,
      transform: 'translateY(-50%)',
      zIndex: 2,
    };
  };

  return (
    <>
      <style>{pulseAnimation}</style>
      <div style={{
        minHeight: '100vh',
        backgroundColor: '#f0f7ff',
        padding: '2rem',
        fontFamily: 'Arial, sans-serif'
      }}>
        <div style={{
          maxWidth: '600px',
          margin: '0 auto',
          backgroundColor: 'white',
          borderRadius: '12px',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
          padding: '2rem'
        }}>
          <h1 style={{
            color: '#2c3e50',
            marginBottom: '1.5rem',
            fontSize: '1.8rem',
            fontWeight: 'bold',
            textAlign: 'center'
          }}>
            My Tasks
          </h1>

          <div style={{
            display: 'flex',
            gap: '8px',
            marginBottom: '2rem'
          }}>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={editingId ? "Update your task..." : "Enter your task..."}
              style={{
                flex: 1,
                padding: '12px 16px',
                borderRadius: '8px',
                border: '2px solid #e2e8f0',
                fontSize: '1rem',
                outline: 'none',
                transition: 'border-color 0.2s',
                borderColor: editingId ? '#3b82f6' : '#e2e8f0'
              }}
              onFocus={e => e.target.style.borderColor = '#3b82f6'}
              onBlur={e => e.target.style.borderColor = editingId ? '#3b82f6' : '#e2e8f0'}
            />
            <button
              onClick={handleSubmit}
              style={{
                backgroundColor: editingId ? '#10b981' : '#3b82f6',
                color: 'white',
                padding: '12px 24px',
                borderRadius: '8px',
                border: 'none',
                fontSize: '1rem',
                cursor: 'pointer',
                transition: 'background-color 0.2s',
                fontWeight: '500',
                minWidth: '100px'
              }}
              onMouseEnter={e => e.target.style.backgroundColor = editingId ? '#059669' : '#2563eb'}
              onMouseLeave={e => e.target.style.backgroundColor = editingId ? '#10b981' : '#3b82f6'}
            >
              {editingId ? 'Update' : 'Add'}
            </button>
          </div>

          <div style={{ marginTop: '1rem', minHeight: '50px' }}>
            {items.length === 0 ? (
              <div style={{
                textAlign: 'center',
                color: '#94a3b8',
                padding: '2rem',
                fontSize: '1.1rem'
              }}>
                No tasks yet. Add some!
              </div>
            ) : (
              items.map((item, index) => (
                <div
                  key={item.id}
                  style={{ position: 'relative', marginBottom: '0.5rem' }}
                >
                  {getDropLineStyle(index) && (
                    <div style={getDropLineStyle(index)} />
                  )}
                  <div
                    draggable
                    onDragStart={(e) => handleDragStart(e, index)}
                    onDragEnd={handleDragEnd}
                    onDragOver={(e) => handleDragOver(e, index)}
                    onDrop={(e) => handleDrop(e, index)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '1rem',
                      backgroundColor: editingId === item.id ? '#e2e8f0' : '#f8fafc',
                      borderRadius: '8px',
                      transition: 'all 0.2s',
                      cursor: 'move',
                      border: editingId === item.id ? '2px solid #3b82f6' : 'none',
                    }}
                    onMouseEnter={e => {
                      if (editingId !== item.id) {
                        e.currentTarget.style.transform = 'translateY(-2px)';
                        e.currentTarget.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.05)';
                      }
                    }}
                    onMouseLeave={e => {
                      if (editingId !== item.id) {
                        e.currentTarget.style.transform = 'translateY(0)';
                        e.currentTarget.style.boxShadow = 'none';
                      }
                    }}
                  >
                    <span style={{
                      fontSize: '1rem',
                      color: '#334155',
                      flex: 1
                    }}>
                      {item.text}
                    </span>
                    <div style={{
                      display: 'flex',
                      gap: '8px'
                    }}>
                      <button
                        onClick={() => handleEdit(item.id, item.text)}
                        style={{
                          backgroundColor: '#e0f2fe',
                          color: '#0284c7',
                          padding: '6px 12px',
                          borderRadius: '6px',
                          border: 'none',
                          fontSize: '0.875rem',
                          cursor: 'pointer',
                          transition: 'all 0.2s',
                        }}
                        onMouseEnter={e => {
                          e.target.style.backgroundColor = '#bae6fd';
                          e.target.style.transform = 'scale(1.05)';
                        }}
                        onMouseLeave={e => {
                          e.target.style.backgroundColor = '#e0f2fe';
                          e.target.style.transform = 'scale(1)';
                        }}
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(item.id)}
                        style={{
                          backgroundColor: '#fee2e2',
                          color: '#ef4444',
                          padding: '6px 12px',
                          borderRadius: '6px',
                          border: 'none',
                          fontSize: '0.875rem',
                          cursor: 'pointer',
                          transition: 'all 0.2s',
                        }}
                        onMouseEnter={e => {
                          e.target.style.backgroundColor = '#fecaca';
                          e.target.style.transform = 'scale(1.05)';
                        }}
                        onMouseLeave={e => {
                          e.target.style.backgroundColor = '#fee2e2';
                          e.target.style.transform = 'scale(1)';
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </>
  );
}

export default TodoApp;
