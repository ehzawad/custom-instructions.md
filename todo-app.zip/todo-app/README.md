# React Todo App with Drag and Drop

A minimalist and interactive todo application built with React, featuring drag-and-drop reordering, smooth animations, and a clean user interface.

![Todo App Screenshot](screenshot.png)

## Features

- ✨ Create, edit, and delete tasks
- 🎯 Drag and drop reordering with visual feedback
- 💫 Smooth animations and transitions
- 🎨 Clean and modern UI
- 📱 Responsive design
- ⌨️ Keyboard support (Enter to add/update tasks)
- 🔄 Real-time state updates

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/react-todo-app.git
cd react-todo-app
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

### Building for Production

To create a production build:
```bash
npm run build
```

The build files will be in the `dist` directory.

## Usage

- **Add Task**: Type your task and press Enter or click Add
- **Edit Task**: Click the Edit button on a task, modify, and click Update
- **Delete Task**: Click the Delete button on a task
- **Reorder Tasks**: Drag and drop tasks to reorder them
- **Visual Feedback**: 
  - Hover effects on tasks
  - Blue indicator line while dragging
  - Color-coded buttons for different actions

## Project Structure

```
src/
  ├── App.js         # Main application component
  ├── index.js       # Entry point
  └── index.css      # Global styles
```

## Dependencies

- React 18.2.0
- React DOM 18.2.0
- @babel/core and related packages for build
- webpack and related packages for bundling

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Inspired by modern todo applications
- Built with React best practices
- Designed with user experience in mind

## Future Enhancements

- [ ] Task categories
- [ ] Due dates
- [ ] Local storage persistence
- [ ] Dark mode
- [ ] Task completion status
- [ ] Filter and search functionality
- [ ] Multiple lists support
- [ ] Cloud sync capabilities
